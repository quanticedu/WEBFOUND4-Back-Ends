function Home() {
        
    return(
        <div><h3>Welcome to Wholly Roasters, a bespoke coffee roastery.</h3>  
        <h3><em>We supply organic coffee beans to clients around the world.</em></h3></div>
        )
}

export default Home;
